var Viewer = angular.module("Viewer", []);

console.log("angular");
